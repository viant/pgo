package mypkg

import (
	"net/http"
	"strconv"
)

type Stringer struct{}

func (p *Stringer) String() string {
	return "hello world" + strconv.Itoa(http.StatusOK)
}

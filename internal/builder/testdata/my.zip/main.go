package main

import "myapp/mypkg"

var Contract = mypkg.Stringer{}
